# cloudinary-pwa-jquery
An app to show how using the principles of Progressive Web Apps can be used to super charge a web app.
